#ifndef COM_BDA_CONTROLLER_EXAMPLE_NATIVEACTIVITY_LISTEN_MAIN
#define COM_BDA_CONTROLLER_EXAMPLE_NATIVEACTIVITY_LISTEN_MAIN

/******************************************************************************/

void onCreate(void);
void onDestroy(void);
void onPause(void);
void onResume(void);

void onDrawFrame(void);
void onSurfaceChanged(int width, int height);
void onSurfaceCreated(void);

/******************************************************************************/

#endif