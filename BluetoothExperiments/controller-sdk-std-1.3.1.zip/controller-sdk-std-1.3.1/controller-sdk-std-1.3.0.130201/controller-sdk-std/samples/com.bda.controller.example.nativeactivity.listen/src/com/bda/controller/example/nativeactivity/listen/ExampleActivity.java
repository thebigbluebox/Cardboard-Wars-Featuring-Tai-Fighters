package com.bda.controller.example.nativeactivity.listen;

/******************************************************************************/

import com.bda.controller.ControllerListener;
import com.bda.controller.KeyEvent;
import com.bda.controller.MotionEvent;
import com.bda.controller.StateEvent;

/******************************************************************************/

public class ExampleActivity
{
	/*
	 * ControllerListener definition.
	 * The JNI function DefineClass is not implemented (see http://developer.android.com/guide/practices/design/jni.html#unsupported).
	 * Therefore class definition can only be done via Java.
	 * 
	 * Inner class only for consistency with other examples.
	 */
	public static class ExampleControllerListener implements ControllerListener
	{
		native void nativeOnKeyEvent(KeyEvent event);

		native void nativeOnMotionEvent(MotionEvent event);

		native void nativeOnStateEvent(StateEvent event);

		@Override
		public void onKeyEvent(KeyEvent event)
		{
			nativeOnKeyEvent(event);
		}

		@Override
		public void onMotionEvent(MotionEvent event)
		{
			nativeOnMotionEvent(event);
		}

		@Override
		public void onStateEvent(StateEvent event)
		{
			nativeOnStateEvent(event);
		}
	}
}