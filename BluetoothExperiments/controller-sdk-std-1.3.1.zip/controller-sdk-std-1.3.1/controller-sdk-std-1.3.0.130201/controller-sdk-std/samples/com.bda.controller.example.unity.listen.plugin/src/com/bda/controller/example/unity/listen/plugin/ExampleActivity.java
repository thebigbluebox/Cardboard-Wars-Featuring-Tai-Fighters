package com.bda.controller.example.unity.listen.plugin;

/******************************************************************************/

import com.bda.controller.ControllerListener;
import com.bda.controller.KeyEvent;
import com.bda.controller.MotionEvent;
import com.bda.controller.StateEvent;
import com.unity3d.player.UnityPlayer;

/******************************************************************************/

public class ExampleActivity
{
	/*
	 * ControllerListener definition.
	 * The JNI function DefineClass is not implemented (see http://developer.android.com/guide/practices/design/jni.html#unsupported).
	 * Therefore class definition can only be done via Java.
	 * 
	 * Inner class only for consistency with other examples.
	 */
	public static class ExampleControllerListener implements ControllerListener
	{
		@Override
		public void onKeyEvent(KeyEvent event)
		{
			UnityPlayer.UnitySendMessage("Example", "onKeyEvent", String.format("%d %d", event.getKeyCode(), event.getAction()));
		}

		@Override
		public void onMotionEvent(MotionEvent event)
		{
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_X, event.getAxisValue(MotionEvent.AXIS_X)));
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_Y, event.getAxisValue(MotionEvent.AXIS_Y)));
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_Z, event.getAxisValue(MotionEvent.AXIS_Z)));
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_RZ, event.getAxisValue(MotionEvent.AXIS_RZ)));
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_LTRIGGER, event.getAxisValue(MotionEvent.AXIS_LTRIGGER)));
			UnityPlayer.UnitySendMessage("Example", "onMotionEvent", String.format("%d %f", MotionEvent.AXIS_RTRIGGER, event.getAxisValue(MotionEvent.AXIS_RTRIGGER)));
		}

		@Override
		public void onStateEvent(StateEvent event)
		{
			UnityPlayer.UnitySendMessage("Example", "onStateEvent", String.format("%d %d", event.getState(), event.getAction()));
		}
	}
}