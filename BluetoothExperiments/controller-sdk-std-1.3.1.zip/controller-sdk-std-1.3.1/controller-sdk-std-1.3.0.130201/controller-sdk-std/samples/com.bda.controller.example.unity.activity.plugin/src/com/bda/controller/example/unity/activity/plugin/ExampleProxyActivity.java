package com.bda.controller.example.unity.activity.plugin;

/******************************************************************************/

import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

/******************************************************************************/

/*
 * Normally, we inherit from com.unity3d.player.UnityPlayerProxyActivity.
 * 
 * However there is no easy way of overriding the classNames array in the
 * onCreate() method.
 * 
 * Therefore, we copy UnityPlayerProxyActivity source and modify the className
 * array in-place.
 */

public class ExampleProxyActivity extends Activity
{
	static protected void copyPlayerPrefs(Context context, String[] activityClassNames)
	{
		// UnityPlayer uses PackageName (bundle identifier) as PlayerPrefs
		// identifier, starting from Unity 3.4.
		final SharedPreferences packagePrefs = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);

		// If PlayerPrefs<package_name> already exists there is no need to copy
		// the old values; they might in fact be stale data.
		if(!packagePrefs.getAll().isEmpty())
		{
			return;
		}

		// Loop through the Activities and copy the contents (if any) of
		// associated PlayerPrefs (Unity 3.3 and earlier).
		final SharedPreferences.Editor playerPrefs = packagePrefs.edit();
		for(final String name : activityClassNames)
		{
			final SharedPreferences prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE);
			final java.util.Map<String, ?> keys = prefs.getAll();
			if(keys.isEmpty())
			{
				continue;
			}
			for(final Map.Entry<String, ?> entry : keys.entrySet())
			{
				final Object value = entry.getValue();
				if(value.getClass() == Integer.class)
				{
					playerPrefs.putInt(entry.getKey(), (Integer) value);
				}
				else if(value.getClass() == Float.class)
				{
					playerPrefs.putFloat(entry.getKey(), (Float) value);
				}
				else if(value.getClass() == String.class)
				{
					playerPrefs.putString(entry.getKey(), (String) value);
				}
			}
			playerPrefs.commit();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		// If the (Native)Activity is overridden these class names must match
		// the new activities.
		final String classNames[] = {"com.bda.controller.example.unity.activity.plugin.ExampleActivity", "com.bda.controller.example.unity.activity.plugin.ExampleNativeActivity"};

		// Convert old PlayerPrefs (pre Unity 3.4) to new PlayerPrefs
		copyPlayerPrefs(this, classNames);

		// Start the most 'advanced' Activity supported by the current Android
		// OS. (Android OS 2.3 ('Gingerbread') and above supports
		// NativeActivity)
		try
		{
			final boolean supportsNative = Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD;
			final Class<?> activity = Class.forName(classNames[supportsNative ? 1 : 0]);
			final Intent intent = new Intent(this, activity);
			intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);

			final Bundle extras = getIntent().getExtras();
			if(extras != null)
			{
				intent.putExtras(extras);
			}

			startActivity(intent);
		}
		catch(final ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally
		{
			finish();
		}
	}
}
