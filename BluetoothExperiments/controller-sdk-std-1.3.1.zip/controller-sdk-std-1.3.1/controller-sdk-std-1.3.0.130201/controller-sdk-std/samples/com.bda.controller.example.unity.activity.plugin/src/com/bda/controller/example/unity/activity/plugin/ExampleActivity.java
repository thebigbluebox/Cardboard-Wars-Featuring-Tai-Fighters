package com.bda.controller.example.unity.activity.plugin;

/******************************************************************************/

import android.os.Bundle;

import com.bda.controller.Controller;
import com.unity3d.player.UnityPlayerActivity;

/******************************************************************************/

public class ExampleActivity extends UnityPlayerActivity
{
	public Controller mController = null;

	public float getAxisValue(int axis)
	{
		return mController.getAxisValue(axis);
	}

	public int getInfo(int info)
	{
		return mController.getInfo(info);
	}

	public int getKeyCode(int keyCode)
	{
		return mController.getKeyCode(keyCode);
	}

	public int getState(int state)
	{
		return mController.getState(state);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		mController = Controller.getInstance(this);
		mController.init();
	}

	@Override
	protected void onDestroy()
	{
		mController.exit();
		super.onDestroy();
	}

	@Override
	protected void onPause()
	{
		mController.onPause();
		super.onPause();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		mController.onResume();
	}
}
